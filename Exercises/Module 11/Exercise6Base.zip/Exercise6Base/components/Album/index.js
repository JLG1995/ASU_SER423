import { Component } from 'react';

export default class Album extends Component {
    render() { }
}